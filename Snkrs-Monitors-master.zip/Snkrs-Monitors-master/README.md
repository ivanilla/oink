# Snkrs-Monitors
Monitor Snkrs CN US JP GB from the app feed

Simply input your webhook url and you will get notifcations when snkrs push a new product on their feed

Looks like this
<img src='example.jpg'>
